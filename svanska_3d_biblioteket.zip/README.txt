SVANSKA 3D BIBLOTEKET
=====================

Filer:
- index.html: hela hemsidan (HTML, CSS och JavaScript i en fil).

Publicera med GitHub Pages:
1. Logga in på https://github.com/ (skapa konto om du inte har ett).
2. Tryck på + uppe till höger och välj New repository.
3. Döp repot till svanska-3d-biblioteket och välj Public.
4. Skapa repot.
5. Välj Add file > Upload files.
6. Ladda upp index.html (inte zip-filen). Tryck Commit changes.
7. Gå till Settings > Pages.
8. Under Build and deployment: välj Deploy from a branch.
9. Välj branch main och folder /(root), tryck Save.
10. Vänta några minuter. På samma Pages-sida visas länken till den publicerade sidan.

Länken brukar ha formen:
https://DITT-GITHUB-NAMN.github.io/svanska-3d-biblioteket/

Obs: byt DITT-GITHUB-NAMN mot ditt faktiska GitHub-användarnamn. Den riktiga länken fungerar först när du publicerat webbplatsen.

Kortens modeller är för närvarande inspirations-exempel, inte STL/3MF-nedladdningar.
